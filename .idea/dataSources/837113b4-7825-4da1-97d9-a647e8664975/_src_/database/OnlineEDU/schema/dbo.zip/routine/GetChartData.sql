-- =============================================
-- Author:		吴翔
-- Create date: 2010/7/7
-- Description:	统计生成图表所用的数据
--				输出格式:
--				time(date) this(int) last(int)
-- =============================================
CREATE PROCEDURE [dbo].[GetChartData] (@type int=0)
AS
BEGIN
declare @i int
if @type=0
begin
	--year
	select convert(date,convert(varchar(4),YEAR(submittime))+'/1/1') as [time],COUNT(*) as this,0 as [last] from tsolution 
	group by YEAR(submittime)
	order by YEAR(submittime) asc
end
else
if @type=1 
begin
	--month
	declare @tmonth table([time] date,[this] int,[last] int)
	declare @thisyear int
	set @thisyear=YEAR(getdate())
	set @i=1
	while @i<=12 
	begin
		insert into @tmonth 
		values(
			convert(datetime,convert(varchar(4),@thisyear)+'/'+convert(varchar(2),@i)+'/1'),
			(select COUNT(*) from tsolution where YEAR(submittime)=@thisyear and MONTH(submittime)=@i),
			(select COUNT(*) from tsolution where YEAR(submittime)=@thisyear-1 and MONTH(submittime)=@i)
			)
		set @i=@i+1
	end
	select * from @tmonth
end
else
begin
	--day (last 28 days)
	declare @tday table([time] date,[this] int,[last] int)
	declare @time date
	set @i=1
	set @time=dateadd(day,1-28,getdate())
	while @i<=28
	begin
		insert into @tday
		values(
			@time,
			(select COUNT(*) from tsolution where @time<=submittime and submittime<dateadd(day,1,@time)),
			(select COUNT(*) from tsolution where dateadd(day,-28,@time)<=submittime and submittime<dateadd(day,1-28,@time))
			)
		set @i=@i+1
		set @time=dateadd(day,1,@time)
	end
	select * from @tday
end
END
