-- Batch submitted through debugger: SQLQuery22.sql|7|0|G:\Users\Wx\AppData\Local\Temp\~vsC64.sql
CREATE PROCEDURE [dbo].[ProblemAccess]
	(
	@username nvarchar(32)=null,
	@pid int,
	@cid int = null
	)
AS
	declare @mid int,@public bit,@namelist int,@editnamelist int
	if @cid is not null
	begin
		--测试存在性
		if (select COUNT(*) from tconprob where contestid=@cid and problemid=@pid)=0 return -1;
		--测试比赛时间
		declare @st datetime,@en datetime
		select @st=starttime,@en=endtime from tcontest where id=@cid
		--比赛未开始
		if Getdate()<=@st return -3
		--比赛进行中
		if @st<=Getdate() and Getdate()<=@en --注释and之后，表示比赛后仍然按照比赛显示
		begin
			select @namelist=namelistid,@editnamelist=editnamelistid from tcontest where id=@cid
			--如果不公开而且名单中没有此人
			if @namelist is not null and (select COUNT(*) from tnamelistd where (namelistid=@namelist or namelistid=@editnamelist) and username=@username and status='Accepted')=0 return -1
			--公开或此人属于该比赛
			else return @cid
		end
		--比赛已结束
		return @cid
	end
	
	--测试存在性 
	if (select COUNT(*) from tproblem where id=@pid)=0 return -1;
	--测试此题是否正在或即将竞赛
	select top 1 @cid=contestid from tconprob where problemid=@pid and contestid in (select id from tcontest where endtime>Getdate())
	if @cid is not null 
	begin
		--如果只有一场比赛则返回比赛id，否则报错
		if (select count(*) from tconprob where problemid=@pid and contestid in (select id from tcontest where endtime>Getdate()))=1 return @cid
		return -2
	end
	--不在比赛中，测试普通可见性
	select @mid=moduleid,@public=ispublic from tproblem where id=@pid
	if @public=0 return -1
	select @namelist=namelistid from tmodule where id=@mid
	if @namelist is not null and (select COUNT(*) from tnamelistd where namelistid=@namelist and username=@username and status='Accepted')=0 return -1
	return 0
