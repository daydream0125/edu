CREATE PROCEDURE [dbo].[NewsSave]
	(
	@username nvarchar(32),
	@id int=null,
	@title nvarchar(max),
	@addtime datetime=null,
	@content nvarchar(max),
	@filename nvarchar(260)=null,
	@attachment varbinary(max)=null
	)
AS
	if @id is null
	begin
		--set @id=1;
		--while (select id from tnews where id=@id) is not null
		--	set @id=@id+1;
		if @addtime is null set @addtime=CURRENT_TIMESTAMP
		insert into tnews (username,title,addtime,content,filename,attachment) values(@username,@title,@addtime,@content,@filename,@attachment)
	end
	else
	begin
		if @filename is null update tnews set username=@username, title=@title, content=@content where id=@id
		else update tnews set username=@username, title=@title, content=@content, filename=@filename, attachment=@attachment where id=@id
	end
