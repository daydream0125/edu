CREATE PROCEDURE [dbo].[UserRegister]
	(
	@username nvarchar(32),
	@pwhash nvarchar(32),
	@nickname nvarchar(32),
	@power int,
	@email nvarchar(50)
	)
AS
	if (select count(username) from tuser where lower(username)=lower(@username))>0 return 1;
	if (select count(nickname) from tuser where lower(nickname)=lower(@nickname))>0 return 2;
	if (select count(email) from tuser where email=@email and (power&2048)>0)>0 return 3;
	insert into tuser(username,pwhash,nickname,[power],email,firsttime) values(@username,@pwhash,@nickname,@power,@email,CURRENT_TIMESTAMP)
	return 0;
