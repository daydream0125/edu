CREATE PROCEDURE [dbo].[SolutionResultSet]
	(
	@id int,
	@result nvarchar(64),
	@resultex nvarchar(max)=null,
	@time float=null,
	@memory int=null,
	@rawtime float=null,
	@rawmemory int=null
	)
AS
	declare @username nvarchar(32),@pid int;
	
	update tsolution set result=@result,resultex=@resultex,timeusage=@time,memoryusage=@memory,
			@username=username,@pid=problemid,rawtimeusage=@rawtime,rawmemoryusage=@rawmemory,judgetime=GETDATE()
			where id=@id
	
	if @result='Accepted' and (select [power] & 2 from tuser where username=@username)=0 
	begin
		update tuser set acsolution=acsolution+1 where username=@username
		update tproblem set acsolution=acsolution+1 where id=@pid
		if(select COUNT(id) from tsolution where username=@username and problemid=@pid and result='Accepted')=1
		begin
			update tuser set acproblem=acproblem+1 where username=@username
			update tproblem set acuser=acuser+1 where id=@pid
		end
	end
