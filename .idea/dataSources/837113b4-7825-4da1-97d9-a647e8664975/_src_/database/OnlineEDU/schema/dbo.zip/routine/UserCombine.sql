
-- =============================================
-- Author:		吴翔
-- Create date: 2012/2/10
-- Description:	合并用户
-- =============================================
CREATE PROCEDURE [dbo].[UserCombine]
	(@fromuser nvarchar(32),
	@touser nvarchar(32))
AS
BEGIN
--change username in all related table
--delete unwanted user in tuser
	declare @firsttime datetime
	declare @pw nvarchar(32)
	set nocount on

	if (select count(*) from tuser where username=@fromuser or username=@touser)<>2 return 1

	begin tran
	begin try
		update tanalysis set username=@touser where username=@fromuser
		update tclarify set username=@touser where username=@fromuser
		update tclarify set replier=@touser where replier=@fromuser
		update tcontest set owner=@touser where owner=@fromuser
		update temail set initiator=@touser where initiator=@fromuser
		update temail set receiver=@touser where receiver=@fromuser
		update tloginlog set username=@touser where username=@fromuser 
		update tmail set sender=@touser where sender=@fromuser
		update tmail set receiver=@touser where receiver=@fromuser
		update tnamelist set owner=@touser where owner=@fromuser
		update tnamelistd set username=@touser where username=@fromuser
		update tnews set username=@touser where username=@fromuser
		update tproblem set editor=@touser where editor=@fromuser
		update tsolution set username=@touser where username=@fromuser 

		--不能合并权限，因为某些权限与用户信息有关
		select @firsttime=MIN(firsttime) from tuser where username=@fromuser or username=@touser
		select top 1 @pw=pwhash from tuser where username=@fromuser or username=@touser order by lasttime desc
		update tuser set pwhash=@pw,firsttime=@firsttime where username=@touser
		delete from tuser where username=@fromuser

		exec SolutionRecount
		commit
		return 0
	end try
	begin catch
		rollback
		return 2
	end catch
END

