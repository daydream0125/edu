CREATE PROCEDURE [dbo].[SolutionRejudge]
	(
	@solutionid int=null,
	@problemid int=null
	)
AS
	--重判Solution
	if @solutionid is not null 
	begin
		declare @username nvarchar(32),@result nvarchar(64);
		select @username=username,@result=result,@problemid=problemid from tsolution where id=@solutionid
		if @result='Accepted' and (select [power] & 2 from tuser where username=@username)=0 
		--排除不复位的情况
		begin
			update tuser set acsolution=acsolution-1 where username=@username
			update tproblem set acsolution=acsolution-1 where id=@problemid
			if(select COUNT(id) from tsolution where username=@username and problemid=@problemid and result='Accepted')=1
			begin
				update tuser set acproblem=acproblem-1 where username=@username
				update tproblem set acuser=acuser-1 where id=@problemid
			end
		end
		update tsolution set result='',resultex=null,timeusage=null,memoryusage=null,
			rawtimeusage=null,rawmemoryusage=null,judgetime=null
			where id=@solutionid
		return
	end
	--重判Problem
	if @problemid is not null
	begin		
		declare @sol table(username nvarchar(32),s nchar)
		--锁住表项
		update tsolution set result=result,resultex=null,timeusage=null,memoryusage=null,
			rawtimeusage=null,rawmemoryusage=null,judgetime=null
			where problemid=@problemid
		--A
		insert into @sol(username,s)
		select username,
			case 
				when result='Accepted' then 'a' 
				else 'e' --wrong and else
			end 
		from tsolution where problemid=@problemid

		update tuser set
			acproblem=acproblem-(case when (	select COUNT(s) from @sol where username=tuser.username and s='a')>0 then 1 else 0 end),
			acsolution=acsolution-(				select COUNT(s) from @sol where username=tuser.username and s='a')
		where power & 2 = 0
		--B
		update tsolution set result='',resultex=null,timeusage=null,memoryusage=null,
			rawtimeusage=null,rawmemoryusage=null,judgetime=null
			where problemid=@problemid
		--A/B处 统计与更新不处理会有并发问题,有问题时重判需要暂停评判程序
		update tproblem set acsolution=0,acuser=0 where id=@problemid
	end
