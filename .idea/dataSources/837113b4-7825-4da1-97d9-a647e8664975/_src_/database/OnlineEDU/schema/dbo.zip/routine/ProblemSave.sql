CREATE PROCEDURE [dbo].[ProblemSave]
	(
	@u nvarchar(32),
	@id int=null,
	@moduleid int,
	@t nvarchar(max),
	@d nvarchar(max),
	@i nvarchar(max),
	@o nvarchar(max),
	@si nvarchar(max),
	@so nvarchar(max),
	@h nvarchar(max),
	@s nvarchar(max),
	@tt float,
	@ct float,
	@m float,
	@isp bit,
	@isc bit,
	@iss bit,
	@addtime datetime=null
	)
AS
	if @ct>@tt set @ct=@tt
	if @m>2047 set @m=2047
	if @id is null
	begin
		set @id=1;
		while (select id from tproblem where id=@id) is not null
			set @id=@id+1;
		if @addtime is null set @addtime=CURRENT_TIMESTAMP;
		insert into tproblem(id,moduleid,title,description,input,output,sinput,soutput,hint,source,ispublic,iscasej,isspecialj,editor,totaltime,casetime,memory,addtime)
						values(@id,@moduleid,@t,@d,@i,@o,@si,@so,@h,@s,@isp,@isc,@iss,@u,@tt,@ct,@m,@addtime)
	end
	else update tproblem set moduleid=@moduleid,title=@t,description=@d,input=@i,output=@o,sinput=@si,soutput=@so,hint=@h,source=@s,
							ispublic=@isp,iscasej=@isc,isspecialj=@iss,editor=@u,totaltime=@tt,casetime=@ct,memory=@m where id=@id
	return @id
