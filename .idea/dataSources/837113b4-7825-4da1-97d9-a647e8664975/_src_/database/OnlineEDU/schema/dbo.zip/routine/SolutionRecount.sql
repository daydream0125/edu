CREATE PROCEDURE [dbo].[SolutionRecount]
AS

update tproblem
set
ttsolution=(select COUNT(id) from tsolution where problemid=tproblem.id),
ttuser=(select COUNT(username) from tuser where username in (select username from tsolution where problemid=tproblem.id) and power & 2 = 0),
acsolution=(select COUNT(id) from tsolution where problemid=tproblem.id and result='Accepted'),
acuser=(select COUNT(username) from tuser where username in (select username from tsolution where problemid=tproblem.id and result='Accepted') and power & 2 = 0)

update tuser set 
ttproblem=(select COUNT(id) from tproblem where id in (select problemid from tsolution where tsolution.username=tuser.username)),
ttsolution=(select COUNT(id) from tsolution where tsolution.username=tuser.username),
acproblem=(select COUNT(id) from tproblem where id in (select problemid from tsolution where tsolution.username=tuser.username and result='Accepted')),
acsolution=(select COUNT(id) from tsolution where tsolution.username=tuser.username and result='Accepted')

update tuser set acproblem=0 where power & 2 = 2