CREATE PROCEDURE [dbo].[UserConfirm]
	(
	@username varchar(32) output,
	@uid uniqueidentifier,
	@ip varchar(50),
	
	@power int output,
	@nickname nvarchar(16) output,
	@mailunread int output,
	@experience float output
	)
AS
	select @username=username,@power=[power],@nickname=nickname from tuser where username=@username and uid=@uid;
	if @power is null return
	select @mailunread=COUNT(*) from tmail where receiver=@username and isread=0
	select @experience=experience from texperience where username=@username
	if @experience is null set @experience=0
	update tuser set lasttime=CURRENT_TIMESTAMP,lastip=@ip where username=@username;
