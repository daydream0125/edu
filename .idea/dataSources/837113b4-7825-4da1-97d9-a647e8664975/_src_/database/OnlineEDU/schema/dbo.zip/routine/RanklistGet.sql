
-- =============================================
-- Author:		吴翔
-- Create date: 2012-01-28 8:12
-- Description:	返回经验排名结果，可分年级
-- =============================================
CREATE PROCEDURE [dbo].[RanklistGet]
	@toprank int,
	@pagesize int,
	@grade int=null
AS
BEGIN
	declare @total int
	SET NOCOUNT ON
	if @grade is null
	begin
		select @total=COUNT(*) from vexperience with (noexpand)
		select rank,nickname,lasttime,motto, acproblem, ttsolution, experience from(
			SELECT top 100 percent row_number() OVER (ORDER BY experience DESC, nickname ASC) AS rank,
				nickname, lasttime, motto, acproblem, ttsolution, experience
			FROM vexperience with (noexpand)
			ORDER BY experience DESC,  nickname ASC) as t
		where rank between @toprank and @toprank+@pagesize-1
	end
	else
	begin
		select @total=COUNT(*) from vexperience with (noexpand) where grade=@grade
		select rank,nickname,lasttime,motto, acproblem, ttsolution, experience from(
			SELECT top 100 percent row_number() OVER (ORDER BY experience DESC,  nickname ASC) AS rank, 
				nickname, lasttime, motto, acproblem, ttsolution, experience
			FROM vexperience with (noexpand)
			WHERE grade=@grade
			ORDER BY experience DESC,  nickname ASC) as t
		where rank between @toprank and @toprank+@pagesize-1
	end
	return @total
END
