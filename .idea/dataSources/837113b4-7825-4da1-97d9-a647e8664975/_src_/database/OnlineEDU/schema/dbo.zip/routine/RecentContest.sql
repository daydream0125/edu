-- =============================================
-- Author:		吴翔
-- Create date: 2012/2/2 12:26
-- Description:	获取首页比赛列表
-- =============================================
CREATE PROCEDURE [dbo].[RecentContest]
AS
BEGIN
	if ((select COUNT(*) from tcontest where endtime>=CONVERT(date,GETDATE()-1))>0)
		select tcontest.id,tcontest.title,starttime,endtime,namelistid,opentime,closetime,ispublic from tcontest
			left outer join tnamelist on tcontest.namelistid=tnamelist.id
			where endtime in (select distinct top 3 endtime
											from tcontest
											where endtime>=CONVERT(date,GETDATE()-1)
											order by endtime asc)
			order by starttime asc,id asc
	else select tcontest.id,tcontest.title,starttime,endtime,namelistid,opentime,closetime,ispublic from tcontest
			left outer join tnamelist on tcontest.namelistid=tnamelist.id
			where endtime in (select top 1 endtime from tcontest order by endtime desc)
			order by starttime asc,id asc
END
