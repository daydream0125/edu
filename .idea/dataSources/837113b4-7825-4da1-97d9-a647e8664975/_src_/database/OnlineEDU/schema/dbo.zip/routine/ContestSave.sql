-- =============================================
-- Author:		吴翔
-- Create date: 2010-3-3
-- Description:	添加比赛
-- =============================================
CREATE PROCEDURE [dbo].[ContestSave]
	(
	@id int=null,
	@title nvarchar(64),
	@namelistid int=null,
	@editnamelistid int=null,
	@owner nvarchar(32),
	@starttime datetime,
	@endtime datetime,
	@freezetime datetime=null,
	@iscasej bit
	)
AS
	if @id is null 
	begin
		set @id=1;
		while (select id from tcontest where id=@id) is not null
			set @id=@id+1;
		insert into tcontest(id,title,namelistid,editnamelistid,owner,starttime,endtime,freezetime,iscasej) values(@id,@title,@namelistid,@editnamelistid,@owner,@starttime,@endtime,@freezetime,@iscasej)
	end
	else update tcontest set title=@title,namelistid=@namelistid,editnamelistid=@editnamelistid,starttime=@starttime,endtime=@endtime,freezetime=@freezetime,iscasej=@iscasej where id=@id
	return @id
