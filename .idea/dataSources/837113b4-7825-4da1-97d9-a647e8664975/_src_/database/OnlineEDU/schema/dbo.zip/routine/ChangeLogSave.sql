
-- =============================================
-- Author:		吴翔
-- Create date: 2011-02-12 08:52
-- Description:	创建或保存更新
-- =============================================
CREATE PROCEDURE [dbo].[ChangeLogSave]
	@id int=null, 
	@time datetime,
	@target nvarchar(32),
	@type nchar(1),
	@description nvarchar(max),
	@descriptionex nvarchar(max)=null
AS
BEGIN
	SET NOCOUNT ON;

	--验证有效性并自动更正
    if @id is not null and not exists(select id from tchangelog where id=@id) set @id=null
    
    if @id is null insert into tchangelog values(@target,@time,@type,@description,@descriptionex)
    else update tchangelog set target=@target,time=@time,type=@type,description=@description,descriptionex=@descriptionex where id=@id
    
    if @id is null set @id=SCOPE_IDENTITY()
    return @id
END

