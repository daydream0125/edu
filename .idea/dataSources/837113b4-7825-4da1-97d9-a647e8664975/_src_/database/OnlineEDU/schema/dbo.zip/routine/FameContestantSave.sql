-- =============================================
-- Author:		吴翔
-- Create date: 2011-07-24 18:01
-- Description:	插入/保存HOF的队员信息
-- =============================================
CREATE PROCEDURE [dbo].[FameContestantSave]
	(
	@cid int=null,
	@name nvarchar(6),
	@grade int,
	@description nvarchar(max)
	)
AS
BEGIN
	SET NOCOUNT ON;
	if @cid is null insert into tfamecontestant values(@name,@grade,@description)
    else update tfamecontestant set name=@name,grade=@grade,description=@description where id=@cid
    
    if @cid is null set @cid=SCOPE_IDENTITY()
    return @cid
END
