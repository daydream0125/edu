CREATE PROCEDURE [dbo].[SolutionSubmit]
	(
	@u nvarchar(32),
	@id int,
	@compiler nvarchar(16),
	@code nvarchar(max),
	@submittime datetime=null,
	@cid int=null,
	@ip nvarchar(64)
	)
AS
	declare @mid int,@case bit;
	if (select username from tuser where username=@u) is null return -1
	
	DECLARE	@return_value int
	EXEC @return_value = ProblemAccess @u,@id,@cid
	if @return_value<0 return -2
	if @return_value=0 select @case=iscasej from tproblem where id=@id
	else select @case=iscasej from tcontest where id=@cid
	
	--检查ContestTime，因ProblemAccess只是检查是否可以查看，比赛结束后也可能可以查看
	if @submittime is null set @submittime=GETDATE()
	if @cid is not null and (select COUNT(*) from tcontest where id=@cid and starttime<=@submittime and @submittime<=endtime)=0 return -3
	
	declare @lasttime datetime=null
	select top 1 @lasttime=submittime from tsolution where username=@u order by id desc
	if @lasttime is not null if CONVERT(float,getdate()-@lasttime)*86400<10 return -4
	
	declare @sid int
	insert into tsolution(username,ip,problemid,contestid,code,compiler,submittime,iscasej) 
			values(@u,@ip,@id,@cid,@code,@compiler,@submittime,@case)
	set @sid=SCOPE_IDENTITY()
	
	update tuser set ttsolution=ttsolution+1 where username=@u
	if (select power & 2 from tuser where username=@u)=0
		update tproblem set ttsolution=ttsolution+1 where id=@id
	
	if(select COUNT(id) from tsolution where username=@u and problemid=@id)=1
	begin
		update tuser set ttproblem=ttproblem+1 where username=@u
		update tproblem set ttuser=ttuser+1 where id=@id
	end
	
	return @sid
