-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SolutionClearError]
AS
	update tsolution set result='',resultex=null,timeusage=null,memoryusage=null,
		rawtimeusage=null,rawmemoryusage=null,judgetime=null
		where result='Compiling' or result='Judging'
