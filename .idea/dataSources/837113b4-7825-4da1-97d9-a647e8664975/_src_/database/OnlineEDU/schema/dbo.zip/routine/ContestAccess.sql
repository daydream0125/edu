CREATE PROCEDURE [dbo].[ContestAccess]
	(
	@username nvarchar(32),
	@cid int
	)
AS
	declare @r int,@st datetime,@en datetime
	--只有在比赛时间内，参与人员才可以提交sol和cla
	--所有人都可以看到排名，其他的必须有提交权限
	--返回值按位：
		--NoContest = &H0
		--IsExist = &H1
		--IsInProgress = &H2
		--IsEnded = &H4
		--IsOwner = &H8
		--CanSubmit = &H10
		--CanEdit = &H20
	set @r=0;
	--如果cid不存在，则select不起作用@r为0
	select @st=starttime,@en=endtime,
		   @r=1
		    | (case when namelistid is null or (select COUNT(*) from tnamelistd where username=@username and namelistid=tcontest.namelistid and status='Accepted')>0 
					then 16 else 0 end)
			| (case when owner=@username
					then 8 else 0 end)
			| (case when editnamelistid is not null and (select COUNT(*) from tnamelistd where username=@username and namelistid=tcontest.editnamelistid and status='Accepted')>0
					then 32 else 0 end)
	from tcontest where id=@cid
	
	if (@r&8)>0 set @r=@r|32
	if @st<=GETDATE() and GETDATE()<=@en set @r=@r|2
	if @en<GETDATE() set @r=@r|4
	return @r
