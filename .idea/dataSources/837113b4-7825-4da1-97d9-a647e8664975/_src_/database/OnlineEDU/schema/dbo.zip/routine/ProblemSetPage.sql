CREATE PROCEDURE [dbo].[ProblemSetPage] 
(
	@u nvarchar(32),
	@mid int,
	@page int,
	@numperpage int,
	@isasc bit,
	@orderby nvarchar(10)
)
AS
BEGIN
	declare @t table(id int,o int)

	if @orderby='difficulty' and @isasc=1
		select id,title,acuser,ttuser,acsolution,ttsolution,addtime,difficulty,
			(select COUNT(id) from tsolution where problemid=tproblem.id and username=@u and result='Accepted') as aced
		from (select id as id1,ROW_NUMBER() over(order by isnull(difficulty,1000+1.0/(acuser+1)) asc) as row
				from tproblem where moduleid=@mid and ispublic=1) as t1--在括号内部的where and difficulty is not null
		left outer join tproblem on id1=id
		where row between (@page-1)*@numperpage+1 and @page*@numperpage --and difficulty is not null
		order by isnull(difficulty,1000+1.0/(acuser+1)) asc
		
	else if @orderby='difficulty' and @isasc=0
		select id,title,acuser,ttuser,acsolution,ttsolution,addtime,difficulty,
			(select COUNT(id) from tsolution where problemid=tproblem.id and username=@u and result='Accepted') as aced
		from (select id as id1,ROW_NUMBER() over(order by isnull(difficulty,-1.0/(acuser+1)) desc) as row
				from tproblem where moduleid=@mid and ispublic=1) as t1--在括号内部的where and difficulty is not null
		left outer join tproblem on id1=id
		where row between (@page-1)*@numperpage+1 and @page*@numperpage --and difficulty is not null
		order by isnull(difficulty,-1.0/(acuser+1)) desc
		
	else if @orderby='addtime' and @isasc=1
		select id,title,acuser,ttuser,acsolution,ttsolution,addtime,difficulty,
			(select COUNT(id) from tsolution where problemid=tproblem.id and username=@u and result='Accepted') as aced
		from (select id as id1,ROW_NUMBER() over(order by addtime asc) as row
				from tproblem where moduleid=@mid and ispublic=1) as t1
		left outer join tproblem on id1=id
		where row between (@page-1)*@numperpage+1 and @page*@numperpage
		order by addtime asc
		
	else if @orderby='addtime' and @isasc=0
		select id,title,acuser,ttuser,acsolution,ttsolution,addtime,difficulty,
			(select COUNT(id) from tsolution where problemid=tproblem.id and username=@u and result='Accepted') as aced
		from (select id as id1,ROW_NUMBER() over(order by addtime desc) as row
				from tproblem where moduleid=@mid and ispublic=1) as t1
		left outer join tproblem on id1=id
		where row between (@page-1)*@numperpage+1 and @page*@numperpage
		order by addtime desc
		
	else
		select id,title,acuser,ttuser,acsolution,ttsolution,addtime,difficulty,
			(select COUNT(id) from tsolution where problemid=tproblem.id and username=@u and result='Accepted') as aced
		from tproblem where id>(@page-1)*@numperpage and id<=@page*@numperpage and ispublic=1 and moduleid=@mid
		order by id
END
