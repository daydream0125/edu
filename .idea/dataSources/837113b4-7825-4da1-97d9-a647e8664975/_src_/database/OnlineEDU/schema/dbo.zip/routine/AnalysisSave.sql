-- =============================================
-- Author:		吴翔
-- Create date: 2010-12-19
-- Description:	保存解题报告
-- =============================================
CREATE PROCEDURE [dbo].[AnalysisSave]
	(
	@id int=null,
	@username nvarchar(32),
	@problemid int=null,
	@source nvarchar(64),
	@cpid nvarchar(8),
	@title nvarchar(64),
	@description nvarchar(max),
	@input nvarchar(max),
	@output nvarchar(max),
	@sinput nvarchar(max),
	@soutput nvarchar(max),
	@analysis nvarchar(max),
	@code nvarchar(max)
	)
AS
BEGIN
	if @id is null insert into tanalysis values(@username,GETDATE(),@problemid,@source,@cpid,@title,@description,@input,@output,@sinput,@soutput,@analysis,@code)
	else update tanalysis set username=@username,updatetime=GETDATE(),problemid=@problemid,source=@source,cpid=@cpid,title=@title,description=@description,input=@input,output=@output,sinput=@sinput,soutput=@soutput,analysis=@analysis,code=@code where id=@id
	if @id is null select @id=MAX(id) from tanalysis
	return @id
END
