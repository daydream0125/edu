CREATE PROCEDURE [dbo].[SolutionRelable]
AS
	declare @id int,@nid int,@st datetime,@en datetime
	
	update tsolution set contestid=null
	update tcontest set buffer=null
	
	set @id=0;
	while(1=1)
	begin
		set @nid=null
		select top 1 @nid=id,@st=starttime,@en=endtime from tcontest where id>@id order by id asc
		if @nid is null break
		set @id=@nid
		update tsolution set contestid=@id where @st<=submittime and submittime<=@en and problemid in (select problemid from tconprob where contestid=@id)
	end
