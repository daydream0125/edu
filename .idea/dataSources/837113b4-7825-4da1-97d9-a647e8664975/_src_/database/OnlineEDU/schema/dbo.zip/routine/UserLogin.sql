CREATE PROCEDURE [dbo].[UserLogin]
	(
	@username varchar(32) output,
	@pwhash nvarchar(32),
	@isexclusive bit,
	@uid uniqueidentifier output,
	@ip nvarchar(64)
	)
AS
	declare @p int
	--此处不设置@username不影响数据库存储的大小写，因为在UserConfirm中会自动纠正
	--也就是说cookie中可以是小写，而进数据进数据库时就成大写了
	--此处设置只是为了保证tloginlog的正确
	select @p=[power] &1,@username=username from tuser where username=@username and pwhash=@pwhash
	if @p is null or @p=0 return
	
	--密码验证成功
	insert into tloginlog values(@username,getdate(),@ip)
	set @uid=null
	if @isexclusive=0 select @uid=uid from tuser where username=@username
	if @uid is not null return
	set @uid=NEWID()
	update tuser set uid=@uid where username=@username
