-- =============================================
-- Author:		吴翔
-- Create date: 2010-08-08
-- Description:	题目提交排名
-- =============================================
CREATE PROCEDURE [dbo].[ProblemRank]
	(
		@pid int,
		@rankfrom int,
		@count int = 25
	)
AS
BEGIN
	select [rank],id,(select nickname from tuser where username=paged.username) as nickname,acc,
		username,timeusage,memoryusage,codelength ,compiler ,submittime
	from(
		select id,username,timeusage,memoryusage,codelength ,compiler ,submittime,
			ROW_NUMBER() over(order by timeusage,memoryusage,codelength,submittime) as [rank],acc
		from(
			select id,username,timeusage,memoryusage,codelength ,compiler ,submittime ,
				row_number() over (partition by username order by timeusage,memoryusage,codelength,submittime) as r,
				COUNT(*) over(partition by username) as acc
			from tsolution
			where problemid=@pid and result='Accepted' and (select power & 2 from tuser where username=tsolution.username)=0
		) as ranked
		where r=1
		) as paged
	where [rank]>=@rankfrom and [rank]<@rankfrom+@count
END
